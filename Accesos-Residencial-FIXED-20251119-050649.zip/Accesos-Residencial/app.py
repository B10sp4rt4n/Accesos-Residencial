"""
AX-S v10.0 - Sistema de Control de Accesos Residencial
Entry point para Streamlit Cloud - Ejecuta la app principal completa
"""
# Ejecutar index.py que es la app completa con todas las fases
exec(open('index.py').read())
